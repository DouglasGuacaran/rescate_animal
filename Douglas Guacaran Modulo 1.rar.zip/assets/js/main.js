$(document).ready(function () {

        $('.slider').slick({
            slidesToShow:1,
            arrows: false,
            autoplay: true,
        });

})

