Proyecto final de Modulo 1 Sustantiva Python 2

Douglas Guacarán

RUT 26.349.213-7

proyecto creado con:

Bootstrap 5

Javascript

JQuery

